<?php
session_start();
// Usa la ruta relativa correcta
$imagen = "ballena.jpg";
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Puzzle de la Ballena</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h1>Puzzle de la Ballena</h1>
    <div class="indicacion">Arrastra las piezas para armar la imagen.</div>
    <div id="puzzle-container"></div>
    <button id="reset">Reiniciar puzzle</button>
    <script>
        window.PUZZLE_IMG_SRC = "<?php echo $imagen; ?>";
    </script>
    <script src="script.js"></script>
    <script>
function ajustarAltura() {
    parent.postMessage({
        type: "setHeight",
        id: window.frameElement ? window.frameElement.id : "",
        height: document.body.scrollHeight
    }, "*");
}
window.onload = ajustarAltura;
window.addEventListener("message", function(event) {
    if (event.data && event.data.type === "getHeight") {
        ajustarAltura();
    }
});
try {
    new ResizeObserver(ajustarAltura).observe(document.body);
} catch(e) {}
</script>
</body>
</html>