<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Juego de Memorama</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body>
    <h1>Memorama</h1>
    <div id="tablero"></div>
    <div id="mensaje"></div>
    <button id="reiniciar">Reiniciar</button>
    <script src="script.js"></script>
    <script>
function ajustarAltura() {
    parent.postMessage({
        type: "setHeight",
        id: window.frameElement ? window.frameElement.id : "",
        height: document.body.scrollHeight
    }, "*");
}
window.onload = ajustarAltura;
window.addEventListener("message", function(event) {
    if (event.data && event.data.type === "getHeight") {
        ajustarAltura();
    }
});
try {
    new ResizeObserver(ajustarAltura).observe(document.body);
} catch(e) {}
</script>
</body>
</html>