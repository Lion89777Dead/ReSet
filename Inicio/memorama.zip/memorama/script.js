const iconos = ['🍎','🍌','🍇','🍓','🍒','🍍','🥝','🍉'];
let cartas = [];
let cartaVolteada = null;
let bloqueo = false;
let paresEncontrados = 0;

function crearTablero() {
    const tablero = document.getElementById('tablero');
    tablero.innerHTML = '';
    // Duplica los iconos y los mezcla
    cartas = [...iconos, ...iconos]
        .sort(() => Math.random() - 0.5)
        .map((icono, idx) => ({
            id: idx,
            icono,
            volteada: false,
            completada: false
        }));

    cartas.forEach((carta, idx) => {
        const div = document.createElement('div');
        div.className = 'carta';
        div.dataset.idx = idx;
        div.addEventListener('click', voltearCarta);
        tablero.appendChild(div);
    });
    paresEncontrados = 0;
    document.getElementById('mensaje').textContent = '';
}

function voltearCarta(e) {
    if (bloqueo) return;
    const idx = e.target.dataset.idx;
    const carta = cartas[idx];
    if (carta.volteada || carta.completada) return;
    carta.volteada = true;
    actualizarTablero();

    if (!cartaVolteada) {
        cartaVolteada = carta;
    } else {
        bloqueo = true;
        setTimeout(() => {
            if (carta.icono === cartaVolteada.icono) {
                carta.completada = true;
                cartaVolteada.completada = true;
                paresEncontrados++;
                if (paresEncontrados === iconos.length) {
                    document.getElementById('mensaje').textContent = '¡Felicidades! Has encontrado todos los pares 🎉';
                }
            } else {
                carta.volteada = false;
                cartaVolteada.volteada = false;
            }
            cartaVolteada = null;
            bloqueo = false;
            actualizarTablero();
        }, 800);
    }
}

function actualizarTablero() {
    document.querySelectorAll('.carta').forEach((div, idx) => {
        const carta = cartas[idx];
        if (carta.volteada || carta.completada) {
            div.textContent = carta.icono;
            div.classList.add('volteada');
            if (carta.completada) div.classList.add('completada');
        } else {
            div.textContent = '';
            div.classList.remove('volteada', 'completada');
        }
    });
}

document.getElementById('reiniciar').addEventListener('click', crearTablero);

crearTablero();