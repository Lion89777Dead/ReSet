<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Rompecabezas Deslizante</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Rompecabezas</h1>
    <div class="puzzle-container" id="puzzle">
        <?php
        
        $pieces = range(0, 8); 
        shuffle($pieces);     

        foreach ($pieces as $index => $value) {
            $class = $value === 0 ? 'tile empty' : 'tile';
            echo "<div class='$class' data-index='$index' data-value='$value'>$value</div>";
        }
        ?>
    </div>

    <button onclick="resetPuzzle()">Reiniciar</button>

    <script src="script.js"></script>
    <script>
function ajustarAltura() {
    parent.postMessage({
        type: "setHeight",
        id: window.frameElement ? window.frameElement.id : "",
        height: document.body.scrollHeight
    }, "*");
}
window.onload = ajustarAltura;
window.addEventListener("message", function(event) {
    if (event.data && event.data.type === "getHeight") {
        ajustarAltura();
    }
});
try {
    new ResizeObserver(ajustarAltura).observe(document.body);
} catch(e) {}
</script>
    
</body>

</html>

