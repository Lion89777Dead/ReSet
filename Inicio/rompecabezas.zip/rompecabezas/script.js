document.addEventListener("DOMContentLoaded", function () {
    const puzzle = document.getElementById("puzzle");

    puzzle.addEventListener("click", function (e) {
        const tile = e.target;
        if (!tile.classList.contains("tile") || tile.classList.contains("empty")) return;

        const tiles = Array.from(puzzle.children);
        const tileIndex = tiles.indexOf(tile);
        const emptyTile = tiles.find(t => t.classList.contains("empty"));
        const emptyIndex = tiles.indexOf(emptyTile);

        const isAdjacent = checkAdjacent(tileIndex, emptyIndex);
        if (isAdjacent) {
            swapTiles(tile, emptyTile);
        }
    });
});

function checkAdjacent(i, j) {
    const rowI = Math.floor(i / 3), colI = i % 3;
    const rowJ = Math.floor(j / 3), colJ = j % 3;
    return (Math.abs(rowI - rowJ) + Math.abs(colI - colJ)) === 1;
}

function swapTiles(tile1, tile2) {
    const tempValue = tile1.dataset.value;
    tile1.dataset.value = tile2.dataset.value;
    tile2.dataset.value = tempValue;

    tile2.textContent = tile1.textContent;
    tile1.textContent = "";

    tile1.classList.add("empty");
    tile2.classList.remove("empty");
}

function resetPuzzle() {
    location.reload(); 
}